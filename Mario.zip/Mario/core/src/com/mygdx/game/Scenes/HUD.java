package com.mygdx.game.Scenes;

import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.utils.Disposable;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.badlogic.gdx.utils.viewport.Viewport;
import com.mygdx.game.MarioBros;

/**
 * Created by Renan on 24/09/2017.
 */

public class HUD implements Disposable{
    public Stage stage;
    private Viewport viewport; // Novo viewport
    private Integer worldTimer;
    private float timeCount;
    private Integer score;

    Label countdownLabel; // Label é equivalente ao widget, nessa biblioteca gdx
    Label scoreLabel;
    Label timeLabel;
    Label levelLabel;
    Label worldLabel;
    Label marioLabel;

    public HUD(SpriteBatch sb){
        worldTimer = 300;
        timeCount = 0;
        score = 0;

        viewport = new FitViewport(MarioBros.V_WIDTH, MarioBros.V_HEIGHT, new OrthographicCamera());
        stage = new Stage(viewport, sb); // Stage é um bloco que você insere coisas (inicialmente soltas dentro dele)

        Table table = new Table(); // Prender os itens em uma tabela
        table.top(); //  Coloca no topo do nosso stage
        table.setFillParent(true); //  largura do nosso stage

        countdownLabel = new Label(String.format("%03d", worldTimer), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        scoreLabel = new Label(String.format("%06d", score), new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        timeLabel = new Label("TIME", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        levelLabel =new Label("1-1", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        worldLabel =new Label("WORLD", new Label.LabelStyle(new BitmapFont(), Color.WHITE));
        marioLabel =new Label("MARIO", new Label.LabelStyle(new BitmapFont(), Color.WHITE));

        //expandX vai expandir X ao maximo, por isso devemos por em todos para eles dividirem igualmente o eixo X.
        table.add(marioLabel).expandX().padTop(10);
        table.add(worldLabel).expandX().padTop(10);
        table.add(timeLabel).expandX().padTop(10);
        table.row();
        table.add(scoreLabel).expandX();
        table.add(levelLabel).expandX();
        table.add(countdownLabel).expandX();

        //inserir a table no estagio
        stage.addActor(table);

    }

    @Override
    public void dispose() {
        stage.dispose();
    }
}
